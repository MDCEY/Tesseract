﻿using System.Windows.Controls;

namespace Intāfēsu.Pages
{
    /// <summary>
    /// Interaction logic for SerialMonitor.xaml
    /// </summary>
    public partial class SerialMonitor : Page
    {
        public SerialMonitor()
        {
            InitializeComponent();
        }
    }
}
